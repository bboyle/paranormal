/*! THIS BANNER WILL BE REMOVED BY GRUNT MINIFICATION

	Try it and see

*/

/*global bar*/
(function( b ) {
	'use strict';

	var foo = 'foo';

	// THIS FILE IS A TEST ONLY
	foo = 'bar';
	b = 'foo';
	
}( bar ));
