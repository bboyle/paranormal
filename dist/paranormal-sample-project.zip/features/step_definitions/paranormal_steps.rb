# steps

Given /I have 'PhantomJs' on 'Desktop'/ do |variable|
	pending
end


When /I open the test page/ do
	pending
end


Then /I should see '(.*?)' as the page title/ do |title|
	pending
end
