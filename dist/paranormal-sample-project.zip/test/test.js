(function() {
	'use strict';

	// QUnit test

	module( 'PARANORMAL dummy module' );

	test( 'dummy test should pass', 1, function() {

		strictEqual( true, true, 'true is true' );

	});

}());
